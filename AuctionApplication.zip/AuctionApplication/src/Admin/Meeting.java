/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Admin;

import static Admin.Bidding.customerid1;
import static Admin.Bidding.item2;
import static Admin.Bidding.jTable1;
import auctionapplication.customer.login.login;
import com.mysql.jdbc.Blob;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.Timer;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/**
 *
 * @author milavshah
 */
public class Meeting extends javax.swing.JInternalFrame {

    /**
     * Creates new form Bidding
     */
    Statement st;
    Connection con;
    public String customer = null;
    static public String check;
    static JPopupMenu pm;
    Timer timer;
    int sec=60;
    int min = 0;
    static public Socket socket;
    private ObjectOutputStream out;
    public Meeting() throws IOException {
           
         this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
       BasicInternalFrameUI ui=( BasicInternalFrameUI)this.getUI();
         ui.setNorthPane(null);
        initComponents();
        try
        {
           socket = new Socket("localhost", 6667);
           out = new ObjectOutputStream(socket.getOutputStream());
         Class.forName("com.mysql.jdbc.Driver"); 
                con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
                 st = (Statement) con.createStatement();
                 
                ResultSet rs = st.executeQuery("select * from `InsertItem`");
                 while(rs.next())
             {
                 String id = rs.getNString("ID");
                 jComboBox1.addItem(id);
//                 Blob b=(Blob) rs.getBlob(4);//2 means 2nd column data  
//                  byte barr[]=b.getBytes(1,(int)b.length());
//                    Image img = Toolkit.getDefaultToolkit().createImage(barr);
//                    ImageIcon icon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), Image.SCALE_DEFAULT));
//                    jLabel3.setIcon(icon);
                this.customer=rs.getNString("Admin");
                System.out.print(check);
             }
                 //con.close();
                 
        }
        catch(Exception e)
        {
            System.out.println("Error from meeting" +e);
        }
//        socket.close();
    }
    void insert(String id) 
    {
        try{
         Class.forName("com.mysql.jdbc.Driver"); 
                con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
                 st = (Statement) con.createStatement();
            String sql="insert into meeting values(?)";
            PreparedStatement stmt=(PreparedStatement) con.prepareStatement(sql);
            stmt.setNString(1,id);
            stmt.executeUpdate();  
        }
        catch(Exception e)
        {
            System.out.println("Error insert from meeting"+e);
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                
                //ServerSocket ss;  
                      try {  
                    socket=new Socket("localhost",6667);
                    
                    new Meeting().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
                }
              //establishes connection and waits for the client  
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton12 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(505, 383));

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        jLabel1.setText("Item name");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel2.setText("ITEM NAME");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton12.setText("Create");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel4.setText(" ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton12)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(55, 55, 55))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(331, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(93, 93, 93))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(jButton12)
                .addGap(70, 70, 70))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
        // TODO add your handling code here:
         if (evt.getSource() == jComboBox1) {
             String id = (String) jComboBox1.getSelectedItem();
             try{
              ResultSet rs = st.executeQuery("SELECT * FROM `InsertItem` WHERE `ID`= '"+id+ "';");
              while(rs.next())
              {
                 Blob b=(Blob) rs.getBlob(4);
                  byte barr[]=b.getBytes(1,(int)b.length());
                    Image img = Toolkit.getDefaultToolkit().createImage(barr);
                    ImageIcon icon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(jLabel3.getWidth(), jLabel3.getHeight(), Image.SCALE_DEFAULT));
                    jLabel3.setIcon(icon);  
                    String name = rs.getNString("Itemname");
                    jLabel2.setText(name);
                    //con.close();
              }
              
             }
             catch(Exception e)
             {
                 System.out.print(e);
             }
         }
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
         
        
      
        check = (String)jComboBox1.getSelectedItem();
        Bidding menu = new Bidding(check,customer);
         menu.setVisible(true);
        OutputStream outputStream;
//        try {
//            outputStream = socket.getOutputStream();
//             PrintWriter printWriter = new PrintWriter(outputStream, true);
//            printWriter.println(check);
//            printWriter.println(customer);
//            printWriter.flush();
//        } catch (IOException ex) {
//            Logger.getLogger(Meeting.class.getName()).log(Level.SEVERE, null, ex);
//        }
       
          
        timer = new Timer(1000,(ActionEvent e) ->
                {
                   if(sec == 0) 
                   {
                       sec = 60;
                       min --;
                   }
                   if(min<0)
                   {
                       timer.stop();
                       
                       Bidding.jButton1.setEnabled(false);
                        menu.setVisible(false);
                          try {
                    out.writeObject("EndMeeting");
                    Object customer = jTable1.getValueAt(jTable1.getModel().getRowCount()-1, 0);
                    String customerid2 = customer.toString();
                    System.out.println(customerid2);
                    Object prize2 = jTable1.getValueAt(jTable1.getModel().getRowCount()-1, 1);
                    System.out.println(prize2);
                    int prize1 = (int) prize2;
                   
                    SoldList soldList = new SoldList(customerid2, prize1, check);
                    JOptionPane.showMessageDialog(null, customerid2 + " won at prize "+prize1);
                }catch(Exception ew)
                {
                    //System.out.print("No one buy prize");
                    JOptionPane.showMessageDialog(null,"No one buy item...");
                }
                   }
                   else{
                       sec--;
                        jLabel4.setText(String.valueOf(": "+sec+" sec"));
                        jLabel5.setText(String.valueOf(min));
                   }
                });
                timer.start();
       try{
           out.writeObject("startMeeting");
//            outputStream = socket.getOutputStream();
//            PrintWriter printWriter = new PrintWriter(outputStream, true);
//            printWriter.println(check);
//            printWriter.println(customer);
//            printWriter.flush();
            insert(check);
           
       }
       catch(Exception pee)
       {
           System.out.print("Error from metting socket" +pee);
       }
        
        
    }//GEN-LAST:event_jButton12ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton12;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
//int sec=60;
//        int min = 0;
//         timer = new Timer(1000,new ActionListener(){
//            public void actionPerformed(ActionEvent e)
//            {
//              
//              if(sec == 0)
//              {
//                  sec =60;
//                  min --;
//              }
//              if(min<0)
//              {
//                  timer.stop();
//                  jButton1.setEnabled(false);
//                  System.out.println("time is out");