/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Admin;

import com.mysql.jdbc.Blob;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author milavshah
 */
public class SoldList {
     String customerid;
    int prize;
    String itemid;
    public SoldList(String customerid, int prize, String itemid) {
        //initComponents();
        this.customerid=customerid;
        this.prize=prize;
        this.itemid =itemid;
        updated(itemid);
        Statement st;
        
        try { 
            Class.forName("com.mysql.jdbc.Driver"); 
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
            st = (Statement) con.createStatement();
            //PreparedStatement st2 = con.prepareStatement("DELETE FROM `InsertItem` WHERE `ID` = '" + itemid + "';");
            String sql = "SELECT * FROM `InsertItem` where `id` = '"+itemid+"'";
            ResultSet rs = st.executeQuery(sql);
            while(rs.next())
            {
              Blob b=(Blob) rs.getBlob(4);//2 means 2nd column data  
              byte barr[]=b.getBytes(1,(int)b.length());
              String itemname = rs.getNString("itemname");
              insert(barr,itemname);
            }
           
        } 
        
        catch (Exception ex) {
           
        }
            
        
    }
    void insert(byte bt[],String name){
         Statement st;
         String customername = null;   
        try{
         
        Class.forName("com.mysql.jdbc.Driver"); 
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
        st = (Statement) con.createStatement();
        String sql1 = "SELECT * FROM `Register` WHERE `customerid`='"+customerid+"'";
        ResultSet rs1 = st.executeQuery(sql1);

       String sql = "INSERT INTO `soldlist`(`customerid`, `customername`, `prize`, `itemname`, `itemimage`, `itemid`) VALUES (?,?,?,?,?,?);";     
       PreparedStatement pst = con.prepareStatement(sql);
       pst.setString(1,customerid); 
       while(rs1.next())
        {
            customername = rs1.getNString("customer_name");
            pst.setString(2,customername);
        }
       pst.setInt(3, prize);
       pst.setString(4, name);
       pst.setBytes(5, bt);
       pst.setString(6,itemid);
        
       pst.execute(); 
        }
        catch(Exception e)
        {
            System.out.println("Error from soldlist: " +e);
        }
        
        
        
    }

    private void updated(String itemid) {
         try{
         
        Class.forName("com.mysql.jdbc.Driver"); 
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
        Statement st = (Statement) con.createStatement();
        String sm = "UPDATE `InsertItem` SET `available`='Sold out' where `ID` = '"+itemid+"';";
         st.executeUpdate(sm);
         }
         catch(Exception e)
         {
             System.out.println("Error from soldlist (update): " +e);
         }
        
        // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
