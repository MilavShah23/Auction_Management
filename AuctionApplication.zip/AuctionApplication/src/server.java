/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author milavshah
 */
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class server extends JFrame {
    private JTextArea textArea = new JTextArea();

    public server() {
        super("Server");
        add(new JScrollPane(textArea));
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void startServer() {
        try {
            // Create a ServerSocket object and specify the port number
            ServerSocket serverSocket = new ServerSocket(6667);
            appendToTextArea("Server started at " + new Date() + "\n");

            // Listen for incoming client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress().getHostAddress());
                // Create a new thread to handle the client request
                Thread clientThread = new Thread(new ClientHandler(clientSocket));
                clientThread.start();

            }
        } catch (IOException ex) {
            // Handle the exception
        }
    }

    private void appendToTextArea(String message) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                textArea.append(message);
            }
        });
    }

    class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        public void run() {
            try {
                
                // Create input and output streams for the client socket
                 InputStream inputStream = clientSocket.getInputStream();
                OutputStream outputStream = clientSocket.getOutputStream();
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
               
                // Read data from the client and send a response back
                String inputLine = null;
                while ((inputLine = in.readLine()) != null) {
                    appendToTextArea("Received from client " + inputLine);
                    out.println("Server received: " + inputLine);
                    String receivedString1 = in.readLine();
                    outputStream = clientSocket.getOutputStream();
                    DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
                    dataOutputStream.writeUTF(receivedString1);
                    dataOutputStream.flush();
                    String receivedString2 = in.readLine();
                    System.out.println("Received strings from Admin: " + receivedString1 + " " + receivedString2);
                }

                // Close the input and output streams and the client socket
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException ex) {
                // Handle the exception
            }
        }
    }

    public static void main(String[] args) {
        new server().startServer();
    }
}
