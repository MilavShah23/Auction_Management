/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package auctionapplication.customer;

import Admin.AdminMain;
import Admin.Bidding;
import Admin.Meeting;
import auctionapplication.customer.login.login;
import com.mysql.jdbc.Blob;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/**
 *
 * @author milavshah
 */
public class joinbidding extends javax.swing.JInternalFrame {

    /**
     * Creates new form joinbidding
     */
    static Statement st;
    String item  = "";
    static public Socket socket;
   private ObjectInputStream in;
   private ObjectOutputStream out;
   Bidding menu;
   public joinbidding() {
        initComponents();
       //String item  = Meeting.id;
//       try{
//        if (!socket.isClosed() && socket.isConnected())
//        {
//        InputStream inputStream = socket.getInputStream();
//        DataInputStream dataInputStream = new DataInputStream(inputStream);
//        String receivedVariable = dataInputStream.readUTF();
//        System.out.println("Received variable from server: " + receivedVariable);
//        }
//        else
//        {
//            System.out.print("something is wrong");
//        }
//       }
//       catch(Exception e)
//       {
//           System.out.println("error from socket"+e);
//       }
try{
        Class.forName("com.mysql.jdbc.Driver"); 
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
        st = (Statement) con.createStatement();
        String sql= "SELECT LAST(productid) FROM `Meeting`;";
        ResultSet rs = st.executeQuery(sql);
        while(rs.next())
        {
           item = rs.getNString(1);
        }
}
catch(Exception e)
{
    System.out.println("Error from joinbidding (meeting table) "+e);
}
       System.out.println(item);
          this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
       BasicInternalFrameUI ui=( BasicInternalFrameUI)this.getUI();
         ui.setNorthPane(null);
         if(item != null)
         {
             try{
                 //socket = new Socket("localhost", 6667);
                  // Create an input stream for receiving messages from the server
//                 in = new ObjectInputStream(socket.getInputStream());
//
//                    // Create an output stream for sending messages to the server
//                    out = new ObjectOutputStream(socket.getOutputStream());
                    new Thread(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                           try{
                               while(true){
                                    Object message = in.readObject();
                                    if(message.equals("startMeeting"))
                                    {
                                        jButton1.setEnabled(true);
                                        try{
                                         Class.forName("com.mysql.jdbc.Driver"); 
                                        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
                                         st = (Statement) con.createStatement();
                                        String sql= "SELECT * FROM `InsertItem` WHERE `ID`='"+item+"'; ";
                                        ResultSet rs = st.executeQuery(sql);
                                         while(rs.next())
                                        {

                                              jLabel5.setText(rs.getNString("ID"));
                                              jLabel3.setText(rs.getNString("Itemname"));

                                              Blob b=(Blob) rs.getBlob(4);
                                              byte barr[]=b.getBytes(1,(int)b.length());
                                              Image img = Toolkit.getDefaultToolkit().createImage(barr);
                                              //169,134
                                              ImageIcon icon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(169,134, Image.SCALE_DEFAULT));
                                              jLabel7.setIcon(icon);
                                              jLabel2.setText(rs.getNString("Owner"));
                                              jLabel6.setText("ongoing....");

                                        }
                                        }
                                        catch(Exception e)
                                        {
                                            System.out.println("Error from joinbidding " +e);
                                        }
                                         
                                        
                                    }
                                    else if (message.equals("endMeeting")) {
                                        menu.setVisible(false);
                                        try{
                                         Class.forName("com.mysql.jdbc.Driver"); 
                                        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
                                        PreparedStatement st = (PreparedStatement) con.prepareStatement("DELETE FROM meeting WHERE productid = '" + item + "';");
                                        }
                                        catch(Exception e)
                                        {
                                            System.out.println("Error from joinbidding 2 " +e);
                                        }
                                        
                       
                                    }
                               }
                           }
                           catch(Exception e)
                           {
                               
                                jButton1.setEnabled(false);
                               System.out.println("Error"+e);
                                jLabel6.setText("Admin hasn't start yet");
                           }
                        }
                    }).start();
//             Class.forName("com.mysql.jdbc.Driver"); 
//             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root","");
//              st = (Statement) con.createStatement();
//         String sql= "SELECT * FROM `InsertItem` WHERE `ID`='"+item+"'; ";
//         ResultSet rs = st.executeQuery(sql);
//         while(rs.next())
//         {
//             
//               jLabel5.setText(rs.getNString("ID"));
//               jLabel3.setText(rs.getNString("Itemname"));
//                
//               Blob b=(Blob) rs.getBlob(4);
//               byte barr[]=b.getBytes(1,(int)b.length());
//               Image img = Toolkit.getDefaultToolkit().createImage(barr);
//               //169,134
//               ImageIcon icon = new ImageIcon(new ImageIcon(img).getImage().getScaledInstance(169,134, Image.SCALE_DEFAULT));
//               jLabel7.setIcon(icon);
//               jLabel2.setText(rs.getNString("Owner"));
//               jLabel6.setText("ongoing....");
//               
//         }
//             }
//             
//             catch(Exception e)
//             {
//                 System.out.println("Error from joinbidding " +e);
//                 
//             }
//          
//         }
//         else{
//          jButton1.setEnabled(false);
//          jLabel6.setText("Admin hasn't start yet");
//         }
             }catch(Exception e)
             {
               System.out.println(e);
             }
         
    }
   }
   public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                
                //ServerSocket ss;  
                if(socket == null)
                {
                      try {  
                    socket=new Socket("localhost",6667);
                } catch (IOException ex) {
                    Logger.getLogger("error from joining bidding error"+ex);
                }
                      new joinbidding().setVisible(true);
               
            }
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(505, 383));

        jLabel1.setText("owner name:");

        jPanel2.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel3.setText("Item name");

        jButton1.setText("Join");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setText("ID:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
            .addGroup(layout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(67, 67, 67))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String customerid = Main.Customerid;
        System.out.println(customerid);
        if(customerid !=null)
        {
            menu = new Bidding(item,customerid);
            menu.setVisible(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
