/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package auctionapplication.customer.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author milavshah
 */
public class validate {

   
    public static boolean checkuser(String name, String password)
    {
        boolean st = false;
        try
        {            
          Class.forName("com.mysql.jdbc.Driver"); 
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/AuctionManagement","root",""); 
                PreparedStatement ps = con.prepareStatement("select * from Register where CUSTOMERID =? and password =?");
                 ps.setString(1, name);
                 ps.setString(2, password);
                 ResultSet rs =ps.executeQuery();
                 if(name.equals("1234567890") && password.equals("admin1234"))
                 {
                    st = rs.next();
                    System.out.print(st);
                 }
                 
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;     
    }
   
}